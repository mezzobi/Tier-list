/**
 * Renders the unranked image pool and its supporting copy.
 */

import { createImageTile } from './render-items.js';

/**
 * @param {import('./store.js').Board} board
 * @param {HTMLElement} container
 */
export function renderPool(board, container) {
  container.replaceChildren(...board.pool.map(createImageTile));
}

/**
 * Updates the pool's empty-state message and the image counter in the heading.
 * @param {import('./store.js').Board} board
 * @param {{ emptyElement: HTMLElement, countElement: HTMLElement }} elements
 */
export function renderPoolStatus(board, { emptyElement, countElement }) {
  emptyElement.hidden = board.pool.length > 0;

  const ranked = board.tiers.reduce((total, tier) => total + tier.items.length, 0);
  const unranked = board.pool.length;
  countElement.textContent =
    ranked + unranked === 0
      ? 'No images yet'
      : `${unranked} unranked · ${ranked} ranked`;
}
