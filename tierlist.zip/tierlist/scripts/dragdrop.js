/**
 * Pointer-driven drag and drop for image tiles.
 *
 * Using pointer events (instead of the HTML5 drag-and-drop API) keeps mouse,
 * touch and pen working with the same code path — and the browser's native
 * image dragging would otherwise fight a custom ghost.
 */

import { DRAG_THRESHOLD } from './constants.js';
import { createDragSession } from './drag-session.js';
import {
  ITEM_SELECTOR,
  clearHighlight,
  computeInsertIndex,
  findDropZone,
  highlightDropZone,
  listTiles,
} from './drop-target.js';

const AUTO_SCROLL_MARGIN = 72;
const AUTO_SCROLL_MAX_SPEED = 22;

const context = {
  /** @type {HTMLElement | null} */
  layer: null,
  /** @type {{ pointerId: number, tile: HTMLElement, x: number, y: number } | null} */
  pending: null,
  /** @type {import('./drag-session.js').DragSession | null} */
  session: null,
  pointerId: 0,
  pointer: { x: 0, y: 0 },
  frame: 0,
  /** @type {((result: { imageId: string, location: string, index: number }) => void) | null} */
  onDrop: null,
  /** @type {(() => void) | null} */
  onCancel: null,
};

/**
 * @param {object} options
 * @param {HTMLElement} options.layer Ghost container.
 * @param {(result: { imageId: string, location: string, index: number }) => void} options.onDrop
 * @param {() => void} options.onCancel Called when a drag is aborted (re-render).
 */
export function enableImageDragging({ layer, onDrop, onCancel }) {
  context.layer = layer;
  context.onDrop = onDrop;
  context.onCancel = onCancel;

  document.addEventListener('pointerdown', handlePointerDown);
  document.addEventListener('pointermove', handlePointerMove);
  document.addEventListener('pointerup', handlePointerUp);
  document.addEventListener('pointercancel', handlePointerUp);
  document.addEventListener('keydown', handleKeyDown);
  window.addEventListener('blur', () => abortDrag());
}

/** @param {PointerEvent} event */
function handlePointerDown(event) {
  if (event.pointerType === 'mouse' && event.button !== 0) {
    return;
  }
  const target = event.target;
  if (!(target instanceof Element) || target.closest('.item__remove')) {
    return;
  }
  const tile = target.closest(ITEM_SELECTOR);
  if (!(tile instanceof HTMLElement) || context.session) {
    return;
  }
  context.pending = {
    pointerId: event.pointerId,
    tile,
    x: event.clientX,
    y: event.clientY,
  };
}

/** @param {PointerEvent} event */
function handlePointerMove(event) {
  if (context.session) {
    if (event.pointerId !== context.pointerId) {
      return;
    }
    event.preventDefault();
    updatePointer(event.clientX, event.clientY);
    return;
  }

  const pending = context.pending;
  if (!pending || event.pointerId !== pending.pointerId) {
    return;
  }
  const travelled = Math.hypot(event.clientX - pending.x, event.clientY - pending.y);
  if (travelled < DRAG_THRESHOLD) {
    return;
  }

  context.session = createDragSession({
    tile: pending.tile,
    layer: context.layer,
    pointerX: pending.x,
    pointerY: pending.y,
  });
  context.pointerId = event.pointerId;
  context.pending = null;

  updatePointer(event.clientX, event.clientY);
  context.frame = requestAnimationFrame(autoScrollTick);
}

function updatePointer(x, y) {
  const session = context.session;
  if (!session) {
    return;
  }
  context.pointer = { x, y };
  session.move(x, y);
  previewDrop(x, y);
}

/**
 * Moves the real tile into the hovered drop zone so the user sees where the
 * image will land; the state commit happens on pointer up.
 */
function previewDrop(x, y) {
  const session = context.session;
  if (!session) {
    return;
  }
  const zone = findDropZone(x, y);
  if (!zone) {
    clearHighlight();
    return;
  }
  highlightDropZone(zone);

  const tiles = listTiles(zone, session.tile);
  const index = computeInsertIndex(tiles, x, y);
  const reference = tiles[index] ?? null;
  const alreadyPlaced =
    session.tile.parentElement === zone && session.tile.nextElementSibling === reference;
  if (!alreadyPlaced) {
    zone.insertBefore(session.tile, reference);
  }
}

/** @param {PointerEvent} event */
function handlePointerUp(event) {
  context.pending = null;
  const session = context.session;
  if (!session || event.pointerId !== context.pointerId) {
    return;
  }
  const result = session.resolve();
  endDrag();
  if (result && result.index !== -1) {
    context.onDrop?.(result);
  } else {
    context.onCancel?.();
  }
}

function abortDrag() {
  context.pending = null;
  if (!context.session) {
    return;
  }
  endDrag();
  context.onCancel?.();
}

function endDrag() {
  cancelAnimationFrame(context.frame);
  context.frame = 0;
  context.session?.destroy();
  context.session = null;
  clearHighlight();
}

/** @param {KeyboardEvent} event */
function handleKeyDown(event) {
  if (event.key === 'Escape' && context.session) {
    event.preventDefault();
    abortDrag();
  }
}

function autoScrollTick() {
  const session = context.session;
  if (!session) {
    return;
  }
  const { x, y } = context.pointer;
  const viewportHeight = window.innerHeight;
  let delta = 0;

  if (y < AUTO_SCROLL_MARGIN) {
    delta = -Math.ceil(((AUTO_SCROLL_MARGIN - y) / AUTO_SCROLL_MARGIN) * AUTO_SCROLL_MAX_SPEED);
  } else if (y > viewportHeight - AUTO_SCROLL_MARGIN) {
    const overflow = y - (viewportHeight - AUTO_SCROLL_MARGIN);
    delta = Math.ceil((overflow / AUTO_SCROLL_MARGIN) * AUTO_SCROLL_MAX_SPEED);
  }

  if (delta !== 0) {
    window.scrollBy(0, delta);
    previewDrop(x, y);
  }
  context.frame = requestAnimationFrame(autoScrollTick);
}
