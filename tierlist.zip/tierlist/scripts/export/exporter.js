/**
 * Top-level export entry points: build the canvas and hand the user a PNG.
 */

import { computeLayout } from './layout.js';
import { measureBoardImages } from './measure.js';
import { renderLayoutToCanvas } from './render.js';

const REVOKE_DELAY_MS = 10_000;
const PIXEL_SUFFIX = 'image/png';

/**
 * @param {import('../store.js').Board} board
 * @returns {Promise<{ canvas: HTMLCanvasElement, layout: import('./layout.js').BoardLayout }>}
 */
export async function createBoardCanvas(board) {
  const measured = await measureBoardImages(board);
  const layout = computeLayout(board, measured);
  return { canvas: renderLayoutToCanvas(layout, measured), layout };
}

/**
 * Renders the board and triggers a PNG download.
 * @param {import('../store.js').Board} board
 * @returns {Promise<{ width: number, height: number, fileName: string }>}
 */
export async function downloadBoardImage(board) {
  const { canvas } = await createBoardCanvas(board);
  const blob = await toBlob(canvas);
  const fileName = buildFileName();
  const url = URL.createObjectURL(blob);

  const link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  link.rel = 'noopener';
  document.body.append(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), REVOKE_DELAY_MS);

  return { width: canvas.width, height: canvas.height, fileName };
}

/**
 * @param {HTMLCanvasElement} canvas
 * @returns {Promise<Blob>}
 */
function toBlob(canvas) {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (blob) {
        resolve(blob);
        return;
      }
      reject(new Error('The PNG could not be generated from the board'));
    }, PIXEL_SUFFIX);
  });
}

/**
 * @param {Date} [date]
 * @returns {string}
 */
export function buildFileName(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `tier-list-${year}-${month}-${day}.png`;
}
