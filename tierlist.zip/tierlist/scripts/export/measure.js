/**
 * Decodes every ranked image once so the exporter can both size tiles
 * (natural aspect ratio) and paint them without a second decode.
 */

import { loadImageElement } from '../media-loader.js';

/**
 * @typedef {object} MeasuredImage
 * @property {number} width
 * @property {number} height
 * @property {HTMLImageElement | null} element Null when the image failed to load.
 */

/**
 * @param {import('../store.js').Board} board
 * @returns {Promise<Map<string, MeasuredImage>>} Keyed by image id.
 */
export async function measureBoardImages(board) {
  const images = board.tiers.flatMap((tier) => tier.items);
  const entries = await Promise.all(images.map(measureOne));
  return new Map(entries);
}

/**
 * @param {import('../store.js').BoardImage} image
 * @returns {Promise<[string, MeasuredImage]>}
 */
async function measureOne(image) {
  try {
    const element = await loadImageElement(image.src);
    return [image.id, { width: element.naturalWidth, height: element.naturalHeight, element }];
  } catch (error) {
    console.warn(`Export: could not decode ${image.name}`, error);
    return [image.id, { width: 1, height: 1, element: null }];
  }
}
