/**
 * Paints a computed board layout onto a 2D canvas context.
 */

import { EXPORT } from '../constants.js';

/**
 * @param {CanvasRenderingContext2D} ctx
 * @param {import('./layout.js').BoardLayout} layout
 * @param {Map<string, import('./measure.js').MeasuredImage>} measured
 */
export function drawBoard(ctx, layout, measured) {
  ctx.fillStyle = EXPORT.background;
  ctx.fillRect(0, 0, layout.width, layout.height);

  layout.rows.forEach((row) => {
    drawRowStrip(ctx, row, layout.width);
    drawLabelCell(ctx, row);
    row.items.forEach((item) => drawTile(ctx, item, measured));
  });
}

/**
 * @param {CanvasRenderingContext2D} ctx
 * @param {import('./layout.js').PlacedRow} row
 * @param {number} boardWidth
 */
function drawRowStrip(ctx, row, boardWidth) {
  ctx.fillStyle = EXPORT.rowBackground;
  ctx.fillRect(EXPORT.padding, row.y, boardWidth - EXPORT.padding * 2, EXPORT.rowHeight);
}

/**
 * @param {CanvasRenderingContext2D} ctx
 * @param {import('./layout.js').PlacedRow} row
 */
function drawLabelCell(ctx, row) {
  ctx.fillStyle = row.tier.color;
  ctx.fillRect(EXPORT.padding, row.y, EXPORT.labelWidth, EXPORT.rowHeight);
  drawTierLetter(ctx, row);
}

/**
 * @param {CanvasRenderingContext2D} ctx
 * @param {import('./layout.js').PlacedRow} row
 */
function drawTierLetter(ctx, row) {
  const maxWidth = EXPORT.labelWidth - 14;
  const centerX = EXPORT.padding + EXPORT.labelWidth / 2;
  const centerY = row.y + EXPORT.rowHeight / 2;

  ctx.save();
  ctx.fillStyle = EXPORT.letterColor;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = fontFor(row.tier.label, maxWidth, ctx);
  /* The trailing maxWidth lets canvas condense any label that still overflows. */
  ctx.fillText(row.tier.label, centerX, centerY, maxWidth);
  ctx.restore();
}

/**
 * Shrinks the letter font so longer tier names still fit the label cell.
 * @param {string} text
 * @param {number} maxWidth
 * @param {CanvasRenderingContext2D} ctx
 * @returns {string}
 */
function fontFor(text, maxWidth, ctx) {
  const base = `700 ${EXPORT.letterFontSize}px ${EXPORT.letterFontFamily}`;
  ctx.font = base;
  const width = ctx.measureText(text).width;
  if (width <= maxWidth) {
    return base;
  }
  const scaled = Math.max(11, Math.floor(EXPORT.letterFontSize * (maxWidth / width)));
  return `700 ${scaled}px ${EXPORT.letterFontFamily}`;
}

/**
 * @param {CanvasRenderingContext2D} ctx
 * @param {import('./layout.js').PlacedItem} item
 * @param {Map<string, import('./measure.js').MeasuredImage>} measured
 */
function drawTile(ctx, item, measured) {
  const element = measured.get(item.image.id)?.element ?? null;
  if (!element) {
    drawMissingTile(ctx, item);
    return;
  }
  ctx.save();
  roundRectPath(ctx, item.x, item.y, item.width, item.height, EXPORT.radius);
  ctx.clip();
  ctx.drawImage(element, item.x, item.y, item.width, item.height);
  ctx.restore();
}

/**
 * Placeholder for an image the browser could not decode.
 * @param {CanvasRenderingContext2D} ctx
 * @param {import('./layout.js').PlacedItem} item
 */
function drawMissingTile(ctx, item) {
  ctx.save();
  roundRectPath(ctx, item.x, item.y, item.width, item.height, EXPORT.radius);
  ctx.fillStyle = EXPORT.fallbackTile;
  ctx.fill();
  ctx.clip();
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.18)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(item.x, item.y);
  ctx.lineTo(item.x + item.width, item.y + item.height);
  ctx.moveTo(item.x + item.width, item.y);
  ctx.lineTo(item.x, item.y + item.height);
  ctx.stroke();
  ctx.restore();
}

/**
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} x
 * @param {number} y
 * @param {number} width
 * @param {number} height
 * @param {number} radius
 */
function roundRectPath(ctx, x, y, width, height, radius) {
  const r = Math.max(0, Math.min(radius, width / 2, height / 2));
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + width - r, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + r);
  ctx.lineTo(x + width, y + height - r);
  ctx.quadraticCurveTo(x + width, y + height, x + width - r, y + height);
  ctx.lineTo(x + r, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}
