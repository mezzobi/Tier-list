/**
 * Creates the off-screen canvas for the export at the configured scale.
 */

import { EXPORT } from '../constants.js';
import { drawBoard } from './draw.js';

/**
 * @param {import('./layout.js').BoardLayout} layout
 * @param {Map<string, import('./measure.js').MeasuredImage>} measured
 * @returns {HTMLCanvasElement}
 */
export function renderLayoutToCanvas(layout, measured) {
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(layout.width * EXPORT.scale);
  canvas.height = Math.round(layout.height * EXPORT.scale);

  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('This browser does not support 2D canvas rendering');
  }
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.scale(EXPORT.scale, EXPORT.scale);
  drawBoard(ctx, layout, measured);

  return canvas;
}
