/**
 * Pure layout maths for the exported PNG: where every row, label and tile sits.
 * All measurements are in CSS pixels; the canvas is scaled up by EXPORT.scale.
 */

import { EXPORT } from '../constants.js';

const MIN_ITEM_WIDTH = 26;

/**
 * @typedef {object} PlacedItem
 * @property {import('../store.js').BoardImage} image
 * @property {number} x
 * @property {number} y
 * @property {number} width
 * @property {number} height
 *
 * @typedef {object} PlacedRow
 * @property {import('../store.js').Tier} tier
 * @property {number} y
 * @property {PlacedItem[]} items
 *
 * @typedef {object} BoardLayout
 * @property {number} width
 * @property {number} height
 * @property {number} contentLeft
 * @property {PlacedRow[]} rows
 */

/**
 * @param {import('../store.js').Board} board
 * @param {Map<string, import('./measure.js').MeasuredImage>} measured
 * @returns {BoardLayout}
 */
export function computeLayout(board, measured) {
  const contentLeft = EXPORT.padding + EXPORT.labelWidth + EXPORT.gutter;
  const rowWidths = board.tiers.map((tier) => sumRowWidth(tier.items, measured));
  const widestRow = rowWidths.reduce((widest, width) => Math.max(widest, width), 0);

  const width = Math.max(EXPORT.minWidth, contentLeft + widestRow + EXPORT.padding);
  const rowCount = Math.max(1, board.tiers.length);
  const height =
    EXPORT.padding * 2 + rowCount * EXPORT.rowHeight + (rowCount - 1) * EXPORT.rowGap;

  const rows = board.tiers.map((tier, index) => {
    const y = EXPORT.padding + index * (EXPORT.rowHeight + EXPORT.rowGap);
    return { tier, y, items: placeItems(tier.items, measured, contentLeft, y) };
  });

  return { width, height, contentLeft, rows };
}

/**
 * Tile width follows the image's aspect ratio so nothing is stretched or
 * cropped, clamped so an extreme panorama cannot dominate the poster.
 * @param {import('../store.js').BoardImage} image
 * @param {Map<string, import('./measure.js').MeasuredImage>} measured
 * @returns {number}
 */
export function tileWidth(image, measured) {
  const size = measured.get(image.id);
  if (!size || size.width <= 0 || size.height <= 0) {
    return EXPORT.itemHeight;
  }
  const aspect = size.width / size.height;
  const width = Math.round(EXPORT.itemHeight * aspect);
  return Math.min(
    Math.max(width, MIN_ITEM_WIDTH),
    Math.round(EXPORT.itemHeight * EXPORT.maxItemWidthRatio)
  );
}

/**
 * @param {import('../store.js').BoardImage[]} items
 * @param {Map<string, import('./measure.js').MeasuredImage>} measured
 * @returns {number}
 */
function sumRowWidth(items, measured) {
  if (items.length === 0) {
    return 0;
  }
  const tiles = items.reduce((total, image) => total + tileWidth(image, measured), 0);
  return tiles + EXPORT.itemGap * (items.length - 1);
}

/**
 * @param {import('../store.js').BoardImage[]} items
 * @param {Map<string, import('./measure.js').MeasuredImage>} measured
 * @param {number} startX
 * @param {number} rowY
 * @returns {PlacedItem[]}
 */
function placeItems(items, measured, startX, rowY) {
  const y = rowY + (EXPORT.rowHeight - EXPORT.itemHeight) / 2;
  let x = startX;

  return items.map((image) => {
    const width = tileWidth(image, measured);
    const placed = { image, x, y, width, height: EXPORT.itemHeight };
    x += width + EXPORT.itemGap;
    return placed;
  });
}
