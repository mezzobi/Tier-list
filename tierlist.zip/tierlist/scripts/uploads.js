/**
 * Wires every way an image can enter the board: the file picker, dragging files
 * onto the window, pasting from the clipboard, and fetching a URL.
 */

import { addImages } from './board-actions.js';
import { loadImageFile, loadImageFromUrl } from './media-loader.js';

/**
 * @param {object} options
 * @param {HTMLInputElement} options.fileInput
 * @param {HTMLElement} options.fileNameLabel
 * @param {HTMLFormElement} options.form
 * @param {HTMLInputElement} options.urlInput
 * @param {HTMLElement} options.submitButton
 * @param {(message: string, isError?: boolean) => void} options.reportStatus
 */
export function setupUploads({ fileInput, fileNameLabel, form, urlInput, submitButton, reportStatus }) {
  fileInput.addEventListener('change', () => {
    const files = [...(fileInput.files ?? [])];
    describeSelection(fileNameLabel, files);
    ingest(files, reportStatus);
    fileInput.value = '';
  });

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    addFromUrl(urlInput, submitButton, reportStatus);
  });

  window.addEventListener('dragover', (event) => {
    if (!hasFiles(event)) {
      return;
    }
    event.preventDefault();
    document.body.classList.add('is-file-dragging');
  });

  window.addEventListener('dragleave', (event) => {
    if (event.relatedTarget === null) {
      document.body.classList.remove('is-file-dragging');
    }
  });

  window.addEventListener('drop', (event) => {
    if (!hasFiles(event)) {
      return;
    }
    event.preventDefault();
    document.body.classList.remove('is-file-dragging');
    ingest([...(event.dataTransfer?.files ?? [])], reportStatus);
  });

  window.addEventListener('paste', (event) => {
    const files = [...(event.clipboardData?.items ?? [])]
      .filter((entry) => entry.kind === 'file')
      .map((entry) => entry.getAsFile())
      .filter((file) => file instanceof File);
    if (files.length > 0) {
      event.preventDefault();
      ingest(files, reportStatus);
    }
  });
}

/**
 * @param {File[]} files
 * @param {(message: string, isError?: boolean) => void} reportStatus
 */
async function ingest(files, reportStatus) {
  if (files.length === 0) {
    return;
  }
  const loaded = [];
  const failures = [];

  for (const file of files) {
    try {
      loaded.push(await loadImageFile(file));
    } catch (error) {
      failures.push(error instanceof Error ? error.message : String(error));
    }
  }

  if (loaded.length > 0) {
    addImages(loaded);
  }
  reportStatus(describeResult(loaded.length, failures), failures.length > 0);
}

/**
 * @param {HTMLInputElement} urlInput
 * @param {HTMLElement} submitButton
 * @param {(message: string, isError?: boolean) => void} reportStatus
 */
async function addFromUrl(urlInput, submitButton, reportStatus) {
  const value = urlInput.value.trim();
  if (value === '') {
    reportStatus('Paste an image URL first', true);
    return;
  }

  submitButton.setAttribute('disabled', 'true');
  reportStatus('Fetching image…');
  try {
    const image = await loadImageFromUrl(value);
    addImages([image]);
    urlInput.value = '';
    reportStatus(`Added ${image.name}`);
  } catch (error) {
    reportStatus(error instanceof Error ? error.message : String(error), true);
  } finally {
    submitButton.removeAttribute('disabled');
  }
}

/**
 * @param {number} addedCount
 * @param {string[]} failures
 * @returns {string}
 */
function describeResult(addedCount, failures) {
  const added =
    addedCount === 1 ? 'Added 1 image' : addedCount > 1 ? `Added ${addedCount} images` : 'No images added';
  if (failures.length === 0) {
    return added;
  }
  return `${added} · ${failures.join(' · ')}`;
}

/**
 * @param {HTMLElement} label
 * @param {File[]} files
 */
function describeSelection(label, files) {
  if (files.length === 0) {
    label.textContent = 'No file chosen';
    return;
  }
  label.textContent = files.length === 1 ? files[0].name : `${files.length} files chosen`;
}

/**
 * @param {DragEvent} event
 * @returns {boolean}
 */
function hasFiles(event) {
  return [...(event.dataTransfer?.types ?? [])].includes('Files');
}
