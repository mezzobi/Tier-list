/**
 * A single in-flight drag: owns the floating ghost and knows how to read the
 * final drop position back out of the DOM.
 */

const DROPZONE_SELECTOR = '[data-dropzone]';

/**
 * @typedef {object} DragSession
 * @property {HTMLElement} tile
 * @property {string} imageId
 * @property {HTMLElement} ghost
 * @property {number} offsetX
 * @property {number} offsetY
 * @property {(x: number, y: number) => void} move
 * @property {() => { imageId: string, location: string, index: number } | null} resolve
 * @property {() => void} destroy
 */

/**
 * @param {object} options
 * @param {HTMLElement} options.tile
 * @param {HTMLElement} options.layer
 * @param {number} options.pointerX
 * @param {number} options.pointerY
 * @returns {DragSession}
 */
export function createDragSession({ tile, layer, pointerX, pointerY }) {
  const rect = tile.getBoundingClientRect();
  const ghost = buildGhost(tile, rect);

  layer.append(ghost);
  tile.classList.add('is-dragging');
  document.body.classList.add('is-dragging-item');

  const offsetX = pointerX - rect.left;
  const offsetY = pointerY - rect.top;

  return {
    tile,
    imageId: tile.dataset.itemId ?? '',
    ghost,
    offsetX,
    offsetY,
    move(x, y) {
      ghost.style.transform = `translate(${x - offsetX}px, ${y - offsetY}px)`;
    },
    resolve() {
      const zone = tile.closest(DROPZONE_SELECTOR);
      const location = zone?.dataset.location;
      if (!zone || !location) {
        return null;
      }
      const index = [...zone.children].indexOf(tile);
      if (index === -1) {
        return null;
      }
      return { imageId: tile.dataset.itemId ?? '', location, index };
    },
    destroy() {
      ghost.remove();
      tile.classList.remove('is-dragging');
      document.body.classList.remove('is-dragging-item');
    },
  };
}

/**
 * @param {HTMLElement} tile
 * @param {DOMRect} rect
 * @returns {HTMLElement}
 */
function buildGhost(tile, rect) {
  const ghost = /** @type {HTMLElement} */ (tile.cloneNode(true));
  ghost.classList.add('drag-ghost');
  ghost.classList.remove('is-dragging');
  ghost.removeAttribute('tabindex');
  ghost.removeAttribute('role');
  ghost.querySelector('.item__remove')?.remove();
  ghost.style.width = `${rect.width}px`;
  ghost.style.height = `${rect.height}px`;
  ghost.style.transform = `translate(${rect.left}px, ${rect.top}px)`;
  return ghost;
}
