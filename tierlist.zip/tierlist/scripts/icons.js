/**
 * Inline SVG icons. Every glyph is drawn from scratch here so the app ships
 * with zero image assets and no icon-font dependency.
 */

const CHEVRON_UP = '<path d="M6 14.5 12 8.5l6 6"/>';
const CHEVRON_DOWN = '<path d="M6 9.5 12 15.5l6-6"/>';

const GEAR = [
  '<circle cx="12" cy="12" r="6.1"/>',
  '<circle cx="12" cy="12" r="2.4"/>',
  ...[0, 45, 90, 135, 180, 225, 270, 315]
    .map(
      (angle) =>
        `<rect x="10.8" y="1.5" width="2.4" height="4.6" rx="1" transform="rotate(${angle} 12 12)"/>`
    )
    .join(''),
].join('');

const TRASH = '<path d="M4 7h16"/><path d="M10 7V4.5h4V7"/><path d="M6.5 7l1 12.5h9L17.5 7"/><path d="M10.5 10.5v6"/><path d="M13.5 10.5v6"/>';

const PATHS = {
  plus: '<path d="M12 5v14"/><path d="M5 12h14"/>',
  close: '<path d="M6.5 6.5 17.5 17.5"/><path d="M17.5 6.5 6.5 17.5"/>',
  download: '<path d="M12 4v10.5"/><path d="M7.5 11 12 15.5 16.5 11"/><path d="M5 19.5h14"/>',
  upload: '<path d="M12 16V5.5"/><path d="M7.5 9.5 12 5 16.5 9.5"/><path d="M5 19.5h14"/>',
  refresh: '<path d="M20 12a8 8 0 1 1-2.4-5.7"/><path d="M20 4v5h-5"/>',
  trash: TRASH,
  image:
    '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="8.5" cy="10" r="1.6"/><path d="M4 17.5 9.5 12l3.5 3.5 2.5-2 4.5 4"/>',
  gear: GEAR,
  'chevron-up': CHEVRON_UP,
  'chevron-down': CHEVRON_DOWN,
  check: '<path d="M5 12.5 10 17.5 19 7.5"/>',
};

/**
 * @param {keyof typeof PATHS} name
 * @param {number} size
 * @returns {string} SVG markup
 */
export function icon(name, size = 18) {
  const paths = PATHS[name];
  if (!paths) {
    throw new Error(`Unknown icon: ${name}`);
  }
  return (
    `<svg class="icon" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" ` +
    'stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" ' +
    `aria-hidden="true" focusable="false">${paths}</svg>`
  );
}

/**
 * Replaces every `[data-icon]` placeholder inside `root` with its SVG.
 * @param {ParentNode} root
 */
export function mountIcons(root = document) {
  root.querySelectorAll('[data-icon]').forEach((placeholder) => {
    const name = placeholder.dataset.icon;
    if (!name || !PATHS[name]) {
      return;
    }
    const size = Number(placeholder.dataset.iconSize ?? 18);
    placeholder.innerHTML = icon(name, size);
    placeholder.removeAttribute('data-icon');
  });
}
