/**
 * Hit-testing helpers for image drag and drop.
 */

export const ITEM_SELECTOR = '.item';
const DROPZONE_SELECTOR = '[data-dropzone]';
const ACTIVE_CLASS = 'is-drop-target';

/** @type {HTMLElement | null} */
let highlighted = null;

/**
 * Finds the drop zone under a viewport point. The drag ghost ignores pointer
 * events, so `elementFromPoint` returns whatever sits underneath it.
 * @param {number} x
 * @param {number} y
 * @returns {HTMLElement | null}
 */
export function findDropZone(x, y) {
  const element = document.elementFromPoint(x, y);
  if (!(element instanceof Element)) {
    return null;
  }
  return /** @type {HTMLElement | null} */ (element.closest(DROPZONE_SELECTOR));
}

/**
 * Index at which the dragged tile should be inserted for the given pointer
 * position, counting only the tiles currently inside the container (the dragged
 * tile itself is excluded by the caller).
 * @param {HTMLElement[]} tiles
 * @param {number} x
 * @param {number} y
 * @returns {number}
 */
export function computeInsertIndex(tiles, x, y) {
  for (let index = 0; index < tiles.length; index += 1) {
    const rect = tiles[index].getBoundingClientRect();
    const sameRow = y >= rect.top && y <= rect.bottom;
    const isBefore = sameRow ? x < rect.left + rect.width / 2 : y < rect.top + rect.height / 2;
    if (isBefore) {
      return index;
    }
  }
  return tiles.length;
}

/**
 * @param {HTMLElement} container
 * @param {HTMLElement} [exclude]
 * @returns {HTMLElement[]}
 */
export function listTiles(container, exclude) {
  return [...container.querySelectorAll(ITEM_SELECTOR)]
    .filter((tile) => tile !== exclude)
    .map((tile) => /** @type {HTMLElement} */ (tile));
}

/**
 * @param {HTMLElement | null} zone
 */
export function highlightDropZone(zone) {
  if (highlighted === zone) {
    return;
  }
  highlighted?.classList.remove(ACTIVE_CLASS);
  highlighted = zone;
  highlighted?.classList.add(ACTIVE_CLASS);
}

export function clearHighlight() {
  highlightDropZone(null);
}
