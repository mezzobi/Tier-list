/**
 * All board mutations. Every function routes through `commit()` so the UI
 * re-renders consistently and the tier layout is persisted.
 */

import {
  DEFAULT_TIERS,
  MAX_TIERS,
  MAX_TIER_LABEL_LENGTH,
  nextTierColor,
  nextTierLabel,
} from './constants.js';
import { findImageLocation, findItems } from './selectors.js';
import { commit, createImage, createTier, getBoard } from './store.js';

/** @returns {string | null} The new tier id, or null when the cap is reached. */
export function addTier() {
  const board = getBoard();
  if (board.tiers.length >= MAX_TIERS) {
    return null;
  }
  const tier = createTier({
    label: nextTierLabel(board.tiers.map((entry) => entry.label)),
    color: nextTierColor(board.tiers.length),
  });
  commit((draft) => {
    draft.tiers.push(tier);
  });
  return tier.id;
}

/**
 * @param {string} tierId
 * @param {number} offset -1 moves the tier up, +1 moves it down.
 */
export function moveTier(tierId, offset) {
  commit((board) => {
    const from = board.tiers.findIndex((tier) => tier.id === tierId);
    const to = from + offset;
    if (from === -1 || to < 0 || to >= board.tiers.length) {
      return;
    }
    const [tier] = board.tiers.splice(from, 1);
    board.tiers.splice(to, 0, tier);
  });
}

/**
 * Deletes a tier; its images return to the pool instead of being destroyed.
 * @param {string} tierId
 */
export function removeTier(tierId) {
  commit((board) => {
    if (board.tiers.length <= 1) {
      return;
    }
    const index = board.tiers.findIndex((tier) => tier.id === tierId);
    if (index === -1) {
      return;
    }
    const [tier] = board.tiers.splice(index, 1);
    board.pool.unshift(...tier.items);
  });
}

/**
 * @param {string} tierId
 * @param {string} label
 */
export function setTierLabel(tierId, label) {
  const trimmed = label.trim().slice(0, MAX_TIER_LABEL_LENGTH);
  commit((board) => {
    const tier = board.tiers.find((entry) => entry.id === tierId);
    if (tier) {
      tier.label = trimmed === '' ? '?' : trimmed;
    }
  });
}

/**
 * @param {string} tierId
 * @param {string} color
 */
export function setTierColor(tierId, color) {
  commit((board) => {
    const tier = board.tiers.find((entry) => entry.id === tierId);
    if (tier) {
      tier.color = color;
    }
  });
}

/** Restores the default S–D tiers; ranked images return to the pool. */
export function resetTiers() {
  commit((board) => {
    const ranked = board.tiers.flatMap((tier) => tier.items);
    board.tiers = createDefaultTiers();
    board.pool.unshift(...ranked);
  });
}

/**
 * @param {{ name: string, src: string, width: number, height: number }[]} images
 */
export function addImages(images) {
  if (images.length === 0) {
    return;
  }
  commit((board) => {
    board.pool.push(...images.map((image) => createImage(image)));
  });
}

/**
 * @param {string} imageId
 */
export function removeImage(imageId) {
  commit((board) => {
    const location = findImageLocation(board, imageId);
    const items = location ? findItems(board, location) : null;
    if (!items) {
      return;
    }
    const index = items.findIndex((image) => image.id === imageId);
    if (index !== -1) {
      items.splice(index, 1);
    }
  });
}

/** Empties every tier and the pool. */
export function clearImages() {
  commit((board) => {
    board.pool = [];
    board.tiers.forEach((tier) => {
      tier.items = [];
    });
  });
}

/**
 * Moves an image to `targetLocation`, inserting it at `index` (an index among
 * the images already there).
 * @param {string} imageId
 * @param {string} targetLocation
 * @param {number} index
 * @returns {boolean} Whether the board changed.
 */
export function moveImage(imageId, targetLocation, index) {
  const fromLocation = findImageLocation(getBoard(), imageId);
  if (!fromLocation) {
    return false;
  }
  const target = findItems(getBoard(), targetLocation);
  if (!target) {
    return false;
  }
  const clamped = Math.max(0, Math.min(index, target.length));
  commit((board) => {
    const source = /** @type {import('./store.js').BoardImage[]} */ (findItems(board, fromLocation));
    const destination = /** @type {import('./store.js').BoardImage[]} */ (findItems(board, targetLocation));
    const fromIndex = source.findIndex((image) => image.id === imageId);
    if (fromIndex === -1) {
      return;
    }
    const [image] = source.splice(fromIndex, 1);
    destination.splice(Math.min(clamped, destination.length), 0, image);
  });
  return true;
}

/** @returns {import('./store.js').Tier[]} */
function createDefaultTiers() {
  return DEFAULT_TIERS.map((tier) => createTier(tier));
}
