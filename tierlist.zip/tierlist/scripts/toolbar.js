/**
 * Toolbar wiring: dispatch button clicks and keep reactive states in sync.
 */

import { MAX_TIERS } from './constants.js';
import { countImages } from './selectors.js';

const ACTION_NAMES = ['add-tier', 'reset-tiers', 'clear-images', 'download'];

/**
 * @param {object} handlers
 * @param {() => void} handlers.onAddTier
 * @param {() => void} handlers.onResetTiers
 * @param {() => void} handlers.onClearImages
 * @param {() => Promise<void>} handlers.onDownload
 * @returns {{ sync: (board: import('./store.js').Board) => void, setDownloadBusy: (busy: boolean) => void }}
 */
export function initToolbar(handlers) {
  const toolbar = document.querySelector('.toolbar');
  if (!toolbar) {
    throw new Error('The toolbar is missing from the page');
  }

  /** @type {Map<string, HTMLButtonElement>} */
  const buttons = new Map();
  ACTION_NAMES.forEach((action) => {
    const button = toolbar.querySelector(`[data-action="${action}"]`);
    if (button instanceof HTMLButtonElement) {
      buttons.set(action, button);
    }
  });

  const downloadLabel = buttons.get('download')?.querySelector('.btn__label') ?? null;
  const idleLabel = downloadLabel?.textContent ?? 'Download PNG';

  toolbar.addEventListener('click', (event) => {
    const target = event.target;
    if (!(target instanceof Element)) {
      return;
    }
    const button = target.closest('[data-action]');
    if (!(button instanceof HTMLElement) || button.hasAttribute('disabled')) {
      return;
    }
    dispatch(button.dataset.action, handlers);
  });

  return {
    sync(board) {
      setDisabled(buttons.get('add-tier'), board.tiers.length >= MAX_TIERS);
      setDisabled(buttons.get('clear-images'), countImages(board) === 0);
    },
    setDownloadBusy(busy) {
      const button = buttons.get('download');
      setDisabled(button, busy);
      if (downloadLabel) {
        downloadLabel.textContent = busy ? 'Rendering…' : idleLabel;
      }
    },
  };
}

/**
 * @param {string | undefined} action
 * @param {object} handlers
 */
function dispatch(action, handlers) {
  switch (action) {
    case 'add-tier':
      handlers.onAddTier();
      break;
    case 'reset-tiers':
      handlers.onResetTiers();
      break;
    case 'clear-images':
      handlers.onClearImages();
      break;
    case 'download':
      handlers.onDownload();
      break;
    default:
      break;
  }
}

/**
 * @param {HTMLButtonElement | undefined} button
 * @param {boolean} disabled
 */
function setDisabled(button, disabled) {
  if (button) {
    button.disabled = disabled;
  }
}
