/**
 * Turns picked files, dropped files and remote URLs into board image records.
 * Images are held as object URLs so they never leave the browser and the
 * canvas export stays untainted.
 */

import { MAX_IMAGE_BYTES } from './constants.js';

const MAX_MEGABYTES = Math.round(MAX_IMAGE_BYTES / (1024 * 1024));

/**
 * @typedef {object} LoadedImage
 * @property {string} name
 * @property {string} src
 * @property {number} width
 * @property {number} height
 */

/**
 * @param {File} file
 * @returns {Promise<LoadedImage>}
 */
export async function loadImageFile(file) {
  if (!file.type.startsWith('image/')) {
    throw new Error(`${file.name} is not an image file`);
  }
  if (file.size > MAX_IMAGE_BYTES) {
    throw new Error(`${file.name} is larger than ${MAX_MEGABYTES} MB`);
  }
  const src = URL.createObjectURL(file);
  try {
    const size = await measureImage(src);
    return { name: file.name, src, ...size };
  } catch (error) {
    URL.revokeObjectURL(src);
    throw error;
  }
}

/**
 * Downloads a remote image so the export canvas stays untainted. Sites that
 * block cross-origin reads will fail here; the caller reports that to the user.
 * @param {string} rawUrl
 * @returns {Promise<LoadedImage>}
 */
export async function loadImageFromUrl(rawUrl) {
  const url = new URL(rawUrl, window.location.href);
  if (!/^https?:$/.test(url.protocol)) {
    throw new Error('Only http and https links are supported');
  }

  let response;
  try {
    response = await fetch(url.href, { mode: 'cors', credentials: 'omit' });
  } catch {
    throw new Error('That site blocked the request — download the image and upload the file instead');
  }
  if (!response.ok) {
    throw new Error(`That link returned ${response.status}`);
  }

  const blob = await response.blob();
  if (!blob.type.startsWith('image/')) {
    throw new Error('That link is not an image');
  }
  if (blob.size > MAX_IMAGE_BYTES) {
    throw new Error(`That image is larger than ${MAX_MEGABYTES} MB`);
  }

  const src = URL.createObjectURL(blob);
  try {
    const size = await measureImage(src);
    return { name: nameFromUrl(url), src, ...size };
  } catch (error) {
    URL.revokeObjectURL(src);
    throw error;
  }
}

/**
 * Decodes an image source into an `HTMLImageElement`.
 * @param {string} src
 * @returns {Promise<HTMLImageElement>}
 */
export function loadImageElement(src) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.decoding = 'async';
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error('The image could not be decoded'));
    image.src = src;
  });
}

/**
 * @param {string} src
 * @returns {Promise<{ width: number, height: number }>}
 */
export async function measureImage(src) {
  const image = await loadImageElement(src);
  return { width: image.naturalWidth, height: image.naturalHeight };
}

/**
 * @param {URL} url
 * @returns {string}
 */
function nameFromUrl(url) {
  const lastSegment = url.pathname.split('/').filter(Boolean).pop();
  return lastSegment ? decodeURIComponent(lastSegment) : url.hostname;
}
