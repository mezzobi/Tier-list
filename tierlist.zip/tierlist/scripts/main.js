/**
 * Application entry point: wires the modules together and keeps the DOM in
 * sync with the store.
 */

import {
  addTier,
  clearImages,
  moveImage,
  moveTier,
  removeImage,
  removeTier,
  resetTiers,
  setTierColor,
  setTierLabel,
} from './board-actions.js';
import { initBoardEvents } from './board-events.js';
import { query } from './dom.js';
import { enableImageDragging } from './dragdrop.js';
import { downloadBoardImage } from './export/exporter.js';
import { mountIcons } from './icons.js';
import { renderBoard } from './render-board.js';
import { renderPool, renderPoolStatus } from './render-pool.js';
import { getBoard, subscribe } from './store.js';
import {
  closeTierSettings,
  initTierSettings,
  openTierSettings,
  syncTierSettings,
} from './tier-settings.js';
import { initToolbar } from './toolbar.js';
import { setupUploads } from './uploads.js';

const boardElement = query('#board');
const poolElement = query('#pool');
const statusElement = query('#upload-status');

mountIcons(document);
const reportStatus = createStatusReporter(statusElement);

const toolbar = initToolbar({
  onAddTier: () => addTier(),
  onResetTiers: () => {
    resetTiers();
    reportStatus('Tiers reset to S–D');
  },
  onClearImages: () => {
    clearImages();
    reportStatus('All images removed');
  },
  onDownload: () => triggerDownload(),
});

initTierSettings({
  onLabel: setTierLabel,
  onColor: setTierColor,
  onMove: moveTier,
  onRemove: (tierId) => {
    removeTier(tierId);
    closeTierSettings();
    reportStatus('Tier deleted — its images returned to the pool');
  },
});

initBoardEvents({
  board: boardElement,
  pool: poolElement,
  handlers: {
    onRemoveImage: removeImage,
    onOpenTierSettings: (tierId, anchor) => openSettingsFor(tierId, anchor),
    onMoveTier: moveTier,
  },
});

setupUploads({
  fileInput: query('#file-input'),
  fileNameLabel: query('#file-name'),
  form: query('#uploader'),
  urlInput: query('#url-input'),
  submitButton: query('.uploader [data-action="add-url"]'),
  reportStatus,
});

enableImageDragging({
  layer: query('#drag-layer'),
  onDrop: ({ imageId, location, index }) => {
    if (!moveImage(imageId, location, index)) {
      render();
    }
  },
  onCancel: () => render(),
});

subscribe(render);
render();

/** Repaints every state-driven part of the page. */
function render() {
  const board = getBoard();
  boardElement.replaceChildren(renderBoard(board));
  renderPool(board, poolElement);
  renderPoolStatus(board, {
    emptyElement: query('#pool-empty'),
    countElement: query('#pool-count'),
  });
  toolbar.sync(board);
  syncTierSettings();
}

/**
 * @param {string} tierId
 * @param {HTMLElement} anchor
 */
function openSettingsFor(tierId, anchor) {
  const board = getBoard();
  const index = board.tiers.findIndex((tier) => tier.id === tierId);
  const tier = board.tiers[index];
  if (!tier) {
    return;
  }
  openTierSettings({
    tierId,
    label: tier.label,
    color: tier.color,
    anchor,
    canMoveUp: index > 0,
    canMoveDown: index < board.tiers.length - 1,
    canDelete: board.tiers.length > 1,
  });
}

async function triggerDownload() {
  toolbar.setDownloadBusy(true);
  reportStatus('Rendering PNG…');
  try {
    const result = await downloadBoardImage(getBoard());
    console.info(`Exported ${result.fileName} (${result.width}×${result.height}px)`);
    reportStatus(`Saved ${result.fileName}`);
  } catch (error) {
    console.error('Export failed', error);
    reportStatus(error instanceof Error ? error.message : 'The PNG could not be created', true);
  } finally {
    toolbar.setDownloadBusy(false);
  }
}

/**
 * @param {HTMLElement} element
 * @returns {(message: string, isError?: boolean) => void}
 */
function createStatusReporter(element) {
  return (message, isError = false) => {
    element.textContent = message;
    element.classList.toggle('status--error', isError);
  };
}
