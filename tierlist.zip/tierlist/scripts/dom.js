/**
 * Tiny DOM helpers used across the editor modules.
 */

import { icon } from './icons.js';

/**
 * @param {string} selector
 * @param {ParentNode} [scope]
 * @returns {HTMLElement}
 */
export function query(selector, scope = document) {
  const element = scope.querySelector(selector);
  if (!element) {
    throw new Error(`Element not found: ${selector}`);
  }
  return /** @type {HTMLElement} */ (element);
}

/**
 * @param {string} selector
 * @param {ParentNode} [scope]
 * @returns {HTMLElement[]}
 */
export function queryAll(selector, scope = document) {
  return [...scope.querySelectorAll(selector)].map((element) => /** @type {HTMLElement} */ (element));
}

/**
 * @param {string} tag
 * @param {string} [className]
 * @param {Record<string, string>} [attributes]
 * @returns {HTMLElement}
 */
export function createElement(tag, className, attributes = {}) {
  const element = document.createElement(tag);
  if (className) {
    element.className = className;
  }
  Object.entries(attributes).forEach(([name, value]) => element.setAttribute(name, value));
  return element;
}

/**
 * Builds a `<button>` carrying an icon and an accessible label.
 * @param {object} options
 * @param {string} options.icon Icon registry name.
 * @param {string} options.label Accessible name (also used as the tooltip).
 * @param {string} [options.className]
 * @param {string} [options.action] Value stored in `data-action`.
 * @param {number} [options.iconSize]
 * @param {boolean} [options.disabled]
 * @returns {HTMLButtonElement}
 */
export function createIconButton({
  icon: iconName,
  label,
  className = 'icon-btn',
  action,
  iconSize = 18,
  disabled = false,
}) {
  const button = /** @type {HTMLButtonElement} */ (document.createElement('button'));
  button.type = 'button';
  button.className = className;
  button.setAttribute('aria-label', label);
  button.title = label;
  button.disabled = disabled;
  if (action) {
    button.dataset.action = action;
  }
  button.innerHTML = icon(iconName, iconSize);
  return button;
}
