/**
 * Board state container.
 *
 * The board holds tiers (each with its own ranked images) plus a pool of
 * unranked images. Image data lives only in memory as blob/data URLs — the
 * persisted record deliberately stores tiers only, matching the promise that
 * uploads "are not saved to the website".
 */

import { DEFAULT_TIERS, STORAGE_KEY } from './constants.js';

/**
 * @typedef {object} BoardImage
 * @property {string} id
 * @property {string} name
 * @property {string} src
 * @property {number} width
 * @property {number} height
 *
 * @typedef {object} Tier
 * @property {string} id
 * @property {string} label
 * @property {string} color
 * @property {BoardImage[]} items
 *
 * @typedef {object} Board
 * @property {Tier[]} tiers
 * @property {BoardImage[]} pool
 */

const listeners = new Set();

/** @type {Board} */
let board = createInitialBoard();

/**
 * @param {string} prefix
 * @returns {string}
 */
export function createId(prefix) {
  const random =
    typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
      ? crypto.randomUUID().replace(/-/g, '').slice(0, 10)
      : Math.random().toString(36).slice(2, 12);
  return `${prefix}_${random}`;
}

/**
 * @param {object} input
 * @param {string} [input.label]
 * @param {string} [input.color]
 * @returns {Tier}
 */
export function createTier({ label = 'S', color = '#ff7f7f' } = {}) {
  return { id: createId('tier'), label, color, items: [] };
}

/**
 * @param {object} input
 * @param {string} input.name
 * @param {string} input.src
 * @param {number} input.width
 * @param {number} input.height
 * @returns {BoardImage}
 */
export function createImage({ name, src, width, height }) {
  return { id: createId('img'), name, src, width, height };
}

/** @returns {Board} */
export function getBoard() {
  return board;
}

/**
 * Subscribes to state changes.
 * @param {(board: Board) => void} listener
 * @returns {() => void} Unsubscribe.
 */
export function subscribe(listener) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

/**
 * Applies a mutation, persists the tier layout and notifies subscribers.
 * @param {(board: Board) => void} mutate
 */
export function commit(mutate) {
  mutate(board);
  persistTiers();
  listeners.forEach((listener) => listener(board));
}

/** @returns {Board} */
function createInitialBoard() {
  const stored = readStoredTiers();
  const tiers = (stored.length > 0 ? stored : DEFAULT_TIERS).map((tier) => createTier(tier));
  return { tiers, pool: [] };
}

/** @returns {{ label: string, color: string }[]} */
function readStoredTiers() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return [];
    }
    const parsed = JSON.parse(raw);
    const tiers = Array.isArray(parsed?.tiers) ? parsed.tiers : [];
    return tiers
      .filter((tier) => tier && typeof tier.label === 'string' && typeof tier.color === 'string')
      .map((tier) => ({ label: tier.label, color: tier.color }));
  } catch (error) {
    console.warn('Could not read the saved tier layout:', error);
    return [];
  }
}

function persistTiers() {
  try {
    const tiers = board.tiers.map(({ label, color }) => ({ label, color }));
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ version: 1, tiers }));
  } catch (error) {
    console.warn('Could not save the tier layout:', error);
  }
}
