/**
 * Builds the DOM for the tier board: one row per tier, each with a coloured
 * label cell, a drop zone for ranked images and a control column.
 */

import { createIconButton } from './dom.js';
import { createImageTile } from './render-items.js';

/**
 * @param {import('./store.js').Board} board
 * @returns {DocumentFragment}
 */
export function renderBoard(board) {
  const fragment = document.createDocumentFragment();
  const total = board.tiers.length;
  board.tiers.forEach((tier, index) => {
    fragment.append(createTierRow(tier, index, total));
  });
  return fragment;
}

/**
 * @param {import('./store.js').Tier} tier
 * @param {number} index
 * @param {number} total
 * @returns {HTMLDivElement}
 */
export function createTierRow(tier, index, total) {
  const row = document.createElement('div');
  row.className = 'tier';
  row.dataset.tierId = tier.id;

  row.append(createLabelCell(tier), createDropZone(tier), createControlCell(tier, index, total));
  return row;
}

/**
 * @param {import('./store.js').Tier} tier
 * @returns {HTMLDivElement}
 */
function createLabelCell(tier) {
  const label = document.createElement('div');
  label.className = 'tier__label';
  label.style.setProperty('--tier-color', tier.color);

  const letter = document.createElement('span');
  letter.className = 'tier__letter';
  letter.textContent = tier.label;

  label.append(letter);
  return label;
}

/**
 * @param {import('./store.js').Tier} tier
 * @returns {HTMLDivElement}
 */
function createDropZone(tier) {
  const zone = document.createElement('div');
  zone.className = 'tier__items';
  zone.dataset.dropzone = '';
  zone.dataset.location = tier.id;
  zone.setAttribute('role', 'list');
  zone.setAttribute('aria-label', `${tier.label} tier images`);
  tier.items.forEach((image) => zone.append(createImageTile(image)));
  return zone;
}

/**
 * @param {import('./store.js').Tier} tier
 * @param {number} index
 * @param {number} total
 * @returns {HTMLDivElement}
 */
function createControlCell(tier, index, total) {
  const controls = document.createElement('div');
  controls.className = 'tier__controls';

  const settings = createIconButton({
    icon: 'gear',
    label: `Settings for tier ${tier.label}`,
    action: 'tier-settings',
    iconSize: 19,
  });

  const chevrons = document.createElement('div');
  chevrons.className = 'tier__chevrons';
  chevrons.append(
    createIconButton({
      icon: 'chevron-up',
      label: `Move tier ${tier.label} up`,
      action: 'tier-up',
      iconSize: 17,
      disabled: index === 0,
    }),
    createIconButton({
      icon: 'chevron-down',
      label: `Move tier ${tier.label} down`,
      action: 'tier-down',
      iconSize: 17,
      disabled: index === total - 1,
    })
  );

  controls.append(settings, chevrons);
  return controls;
}
