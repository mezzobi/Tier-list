/**
 * Renders a single draggable image tile.
 */

import { createIconButton } from './dom.js';

/**
 * @param {import('./store.js').BoardImage} image
 * @returns {HTMLDivElement}
 */
export function createImageTile(image) {
  const tile = document.createElement('div');
  tile.className = 'item';
  tile.dataset.itemId = image.id;
  tile.tabIndex = 0;
  tile.setAttribute('role', 'listitem');
  tile.setAttribute('aria-label', `${image.name} — drag to rank, press Delete to remove`);
  tile.title = image.name;

  const img = document.createElement('img');
  img.src = image.src;
  img.alt = image.name;
  img.draggable = false;
  img.decoding = 'async';
  img.addEventListener('error', () => {
    tile.classList.add('item--broken');
  });

  const removeButton = createIconButton({
    icon: 'close',
    label: `Remove ${image.name}`,
    className: 'item__remove',
    action: 'remove-image',
    iconSize: 12,
  });

  tile.append(img, removeButton);
  return tile;
}
