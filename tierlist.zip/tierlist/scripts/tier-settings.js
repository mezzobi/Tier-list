/**
 * Floating "tier settings" panel: rename, recolour, reorder and delete a tier.
 * One panel instance is reused for every tier.
 */

import { MAX_TIER_LABEL_LENGTH, TIER_COLORS } from './constants.js';
import { createIconButton } from './dom.js';

/** @type {HTMLDivElement | null} */
let panel = null;
/** @type {HTMLInputElement | null} */
let labelInput = null;
/** @type {HTMLInputElement | null} */
let customColor = null;
/** @type {HTMLElement | null} */
let swatchRow = null;
/** @type {HTMLButtonElement | null} */
let moveUpButton = null;
/** @type {HTMLButtonElement | null} */
let moveDownButton = null;
/** @type {HTMLButtonElement | null} */
let deleteButton = null;

let active = null;
let callbacks = { onLabel: () => {}, onColor: () => {}, onMove: () => {}, onRemove: () => {} };

/**
 * Creates the panel once and wires its ambient (document level) listeners.
 * @param {object} handlers
 * @param {(tierId: string, label: string) => void} handlers.onLabel
 * @param {(tierId: string, color: string) => void} handlers.onColor
 * @param {(tierId: string, offset: number) => void} handlers.onMove
 * @param {(tierId: string) => void} handlers.onRemove
 */
export function initTierSettings(handlers) {
  callbacks = handlers;
  panel = buildPanel();
  document.body.append(panel);

  document.addEventListener('pointerdown', (event) => {
    if (!active || !(event.target instanceof Node)) {
      return;
    }
    if (panel?.contains(event.target) || active.anchor.contains(event.target)) {
      return;
    }
    closeTierSettings();
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && active) {
      closeTierSettings();
    }
  });

  window.addEventListener('resize', () => syncTierSettings());
  window.addEventListener('scroll', () => syncTierSettings(), { passive: true });
}

/**
 * @param {object} options
 * @param {string} options.tierId
 * @param {string} options.label
 * @param {string} options.color
 * @param {HTMLButtonElement} options.anchor The gear button that opened the panel.
 * @param {boolean} options.canMoveUp
 * @param {boolean} options.canMoveDown
 * @param {boolean} options.canDelete
 */
export function openTierSettings({ tierId, label, color, anchor, canMoveUp, canMoveDown, canDelete }) {
  if (!panel) {
    return;
  }
  active = { tierId, anchor };
  labelInput.value = label;
  customColor.value = toHex(color);
  moveUpButton.disabled = !canMoveUp;
  moveDownButton.disabled = !canMoveDown;
  deleteButton.disabled = !canDelete;

  const swatches = [...swatchRow.querySelectorAll('.swatch')];
  swatches.forEach((swatch) => {
    swatch.setAttribute('aria-pressed', String(swatch.dataset.color === color));
  });

  panel.hidden = false;
  positionPanel();
  labelInput.focus({ preventScroll: true });
  labelInput.select();
}

export function closeTierSettings() {
  if (!panel || !active) {
    return;
  }
  active = null;
  panel.hidden = true;
}

/** Keeps the panel attached to its gear button across re-renders and scrolls. */
export function syncTierSettings() {
  if (!active) {
    return;
  }
  const { tierId } = active;
  const anchor = document.querySelector(`.tier[data-tier-id="${tierId}"] [data-action="tier-settings"]`);
  if (!(anchor instanceof HTMLElement)) {
    closeTierSettings();
    return;
  }
  active.anchor = anchor;
  positionPanel();
}

/** @returns {string | null} */
export function activeTierId() {
  return active?.tierId ?? null;
}

function buildPanel() {
  const element = document.createElement('div');
  element.className = 'popover';
  element.setAttribute('role', 'dialog');
  element.setAttribute('aria-label', 'Tier settings');
  element.hidden = true;

  element.append(
    buildHeader(),
    buildLabelField(),
    buildColorField(),
    buildActions()
  );
  return element;
}

function buildHeader() {
  const head = document.createElement('div');
  head.className = 'popover__head';

  const title = document.createElement('span');
  title.className = 'popover__title';
  title.textContent = 'Tier settings';

  const close = createIconButton({
    icon: 'close',
    label: 'Close tier settings',
    iconSize: 15,
  });
  close.addEventListener('click', () => closeTierSettings());

  head.append(title, close);
  return head;
}

function buildLabelField() {
  const field = document.createElement('div');
  field.className = 'popover__field';

  const label = document.createElement('label');
  label.className = 'popover__label';
  label.htmlFor = 'tier-label-input';
  label.textContent = 'Tier name';

  labelInput = document.createElement('input');
  labelInput.id = 'tier-label-input';
  labelInput.className = 'popover__input';
  labelInput.type = 'text';
  labelInput.maxLength = MAX_TIER_LABEL_LENGTH;
  labelInput.autocomplete = 'off';
  labelInput.addEventListener('input', () => {
    if (active) {
      callbacks.onLabel(active.tierId, labelInput.value);
    }
  });

  field.append(label, labelInput);
  return field;
}

function buildColorField() {
  const field = document.createElement('div');
  field.className = 'popover__field';

  const label = document.createElement('span');
  label.className = 'popover__label';
  label.textContent = 'Colour';

  swatchRow = document.createElement('div');
  swatchRow.className = 'swatches';
  swatchRow.setAttribute('role', 'group');
  swatchRow.setAttribute('aria-label', 'Tier colours');
  TIER_COLORS.forEach((color) => swatchRow.append(createSwatch(color)));

  const customLabel = document.createElement('label');
  customLabel.className = 'custom-color';
  customLabel.append(document.createTextNode('Custom'));

  customColor = document.createElement('input');
  customColor.type = 'color';
  customColor.setAttribute('aria-label', 'Custom tier colour');
  customColor.addEventListener('input', () => {
    if (active) {
      callbacks.onColor(active.tierId, customColor.value);
    }
  });
  customLabel.append(customColor);

  field.append(label, swatchRow, customLabel);
  return field;
}

function buildActions() {
  const actions = document.createElement('div');
  actions.className = 'popover__actions';

  moveUpButton = createButton('Move up', 'btn');
  moveUpButton.addEventListener('click', () => callbacks.onMove(active?.tierId ?? '', -1));
  moveDownButton = createButton('Move down', 'btn');
  moveDownButton.addEventListener('click', () => callbacks.onMove(active?.tierId ?? '', 1));

  const moveRow = document.createElement('div');
  moveRow.className = 'popover__move-row';
  moveRow.append(moveUpButton, moveDownButton);

  deleteButton = createButton('Delete tier', 'btn btn--danger');
  deleteButton.addEventListener('click', () => {
    const tierId = active?.tierId;
    if (tierId) {
      callbacks.onRemove(tierId);
    }
  });

  const hint = document.createElement('p');
  hint.className = 'popover__hint';
  hint.textContent = 'Deleting a tier sends its images back to the unranked pool.';

  actions.append(moveRow, deleteButton, hint);
  return actions;
}

/**
 * @param {string} text
 * @param {string} className
 * @returns {HTMLButtonElement}
 */
function createButton(text, className) {
  const button = /** @type {HTMLButtonElement} */ (document.createElement('button'));
  button.type = 'button';
  button.className = className;
  button.textContent = text;
  return button;
}

/**
 * @param {string} color
 * @returns {HTMLButtonElement}
 */
function createSwatch(color) {
  const swatch = /** @type {HTMLButtonElement} */ (document.createElement('button'));
  swatch.type = 'button';
  swatch.className = 'swatch';
  swatch.dataset.color = color;
  swatch.style.background = color;
  swatch.setAttribute('aria-label', `Use colour ${color}`);
  swatch.setAttribute('aria-pressed', 'false');
  swatch.addEventListener('click', () => {
    if (active) {
      callbacks.onColor(active.tierId, color);
    }
  });
  return swatch;
}

function positionPanel() {
  if (!panel || !active) {
    return;
  }
  const anchorRect = active.anchor.getBoundingClientRect();
  const { width, height } = panel.getBoundingClientRect();
  const gap = 12;

  let left = anchorRect.left - width - gap;
  if (left < gap) {
    left = Math.min(anchorRect.right + gap, window.innerWidth - width - gap);
  }
  const top = Math.max(gap, Math.min(anchorRect.top - 8, window.innerHeight - height - gap));

  panel.style.left = `${Math.max(gap, left)}px`;
  panel.style.top = `${top}px`;
}

/**
 * `<input type="color">` only accepts `#rrggbb`.
 * @param {string} color
 * @returns {string}
 */
function toHex(color) {
  return /^#[0-9a-f]{6}$/i.test(color) ? color : '#ff7f7f';
}
