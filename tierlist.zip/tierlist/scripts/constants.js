/**
 * Shared constants for the tier list editor.
 * Board metrics are duplicated (CSS variables + canvas export) so the exported
 * PNG lines up with what the user sees on screen.
 */

export const STORAGE_KEY = 'tierlist.board.v1';

/** Sentinel location key for images that are not ranked in any tier. */
export const POOL = 'pool';

export const TIER_COLORS = [
  '#ff7f7f',
  '#ffbf7f',
  '#ffdf7f',
  '#ffff7f',
  '#bfff7f',
  '#7fd9a8',
  '#7fc9ff',
  '#c9a7ff',
];

export const DEFAULT_TIERS = [
  { label: 'S', color: '#ff7f7f' },
  { label: 'A', color: '#ffbf7f' },
  { label: 'B', color: '#ffdf7f' },
  { label: 'C', color: '#ffff7f' },
  { label: 'D', color: '#bfff7f' },
];

const LETTER_SEQUENCE = ['S', 'A', 'B', 'C', 'D', 'E', 'F'];

export const MAX_TIER_LABEL_LENGTH = 14;
export const MAX_TIERS = 14;
export const MAX_IMAGE_BYTES = 12 * 1024 * 1024;

/** Pointer travel (px) before a press turns into a drag. */
export const DRAG_THRESHOLD = 5;

/** Layout for the exported PNG, in CSS pixels (the canvas is scaled up). */
export const EXPORT = {
  scale: 2,
  padding: 12,
  gutter: 10,
  rowHeight: 88,
  labelWidth: 96,
  rowGap: 3,
  itemGap: 6,
  itemHeight: 74,
  maxItemWidthRatio: 3,
  minWidth: 900,
  radius: 4,
  background: '#0c0c0f',
  rowBackground: '#16161a',
  fallbackTile: '#1b1b21',
  letterColor: 'rgba(18, 18, 20, 0.82)',
  letterFontSize: 26,
  letterFontFamily: '"Segoe UI", system-ui, -apple-system, sans-serif',
};

export function nextTierLabel(existingLabels) {
  const used = new Set(existingLabels.map((label) => label.toUpperCase()));
  const unused = LETTER_SEQUENCE.find((candidate) => !used.has(candidate));
  if (unused) {
    return unused;
  }
  return `T${existingLabels.length + 1}`;
}

export function nextTierColor(tierCount) {
  return TIER_COLORS[tierCount % TIER_COLORS.length];
}
