/**
 * Read-only helpers for querying board state.
 */

import { POOL } from './constants.js';

/**
 * @param {import('./store.js').Board} board
 * @param {string} tierId
 * @returns {import('./store.js').Tier | null}
 */
export function findTier(board, tierId) {
  return board.tiers.find((tier) => tier.id === tierId) ?? null;
}

/**
 * Resolves the array that holds the images for a location key
 * (`POOL` or a tier id).
 * @param {import('./store.js').Board} board
 * @param {string} location
 * @returns {import('./store.js').BoardImage[] | null}
 */
export function findItems(board, location) {
  if (location === POOL) {
    return board.pool;
  }
  return findTier(board, location)?.items ?? null;
}

/**
 * @param {import('./store.js').Board} board
 * @param {string} imageId
 * @returns {string | null} Location key holding the image.
 */
export function findImageLocation(board, imageId) {
  if (board.pool.some((image) => image.id === imageId)) {
    return POOL;
  }
  const tier = board.tiers.find((entry) => entry.items.some((image) => image.id === imageId));
  return tier ? tier.id : null;
}

/**
 * @param {import('./store.js').Board} board
 * @param {string} imageId
 * @returns {import('./store.js').BoardImage | null}
 */
export function findImage(board, imageId) {
  return [...board.pool, ...board.tiers.flatMap((tier) => tier.items)].find(
    (image) => image.id === imageId
  ) ?? null;
}

/**
 * @param {import('./store.js').Board} board
 * @returns {number}
 */
export function countImages(board) {
  return board.pool.length + board.tiers.reduce((total, tier) => total + tier.items.length, 0);
}
