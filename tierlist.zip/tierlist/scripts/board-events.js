/**
 * Delegated board + pool interactions: tile removal, tier controls and the
 * keyboard equivalent of removing a focused tile.
 */

/**
 * @param {object} options
 * @param {HTMLElement} options.board
 * @param {HTMLElement} options.pool
 * @param {object} options.handlers
 * @param {(imageId: string) => void} options.handlers.onRemoveImage
 * @param {(tierId: string, anchor: HTMLElement) => void} options.handlers.onOpenTierSettings
 * @param {(tierId: string, offset: number) => void} options.handlers.onMoveTier
 */
export function initBoardEvents({ board, pool, handlers }) {
  [board, pool].forEach((container) => {
    container.addEventListener('click', (event) => handleClick(event, handlers));
    container.addEventListener('keydown', (event) => handleKeyDown(event, handlers));
  });
}

/**
 * @param {MouseEvent} event
 * @param {object} handlers
 */
function handleClick(event, handlers) {
  const target = event.target;
  if (!(target instanceof Element)) {
    return;
  }
  const button = target.closest('[data-action]');
  if (!(button instanceof HTMLElement)) {
    return;
  }

  const tierId = button.closest('.tier')?.dataset.tierId ?? '';
  const imageId = button.closest('.item')?.dataset.itemId ?? '';

  switch (button.dataset.action) {
    case 'remove-image':
      if (imageId) {
        handlers.onRemoveImage(imageId);
      }
      break;
    case 'tier-settings':
      if (tierId) {
        handlers.onOpenTierSettings(tierId, button);
      }
      break;
    case 'tier-up':
      if (tierId) {
        handlers.onMoveTier(tierId, -1);
      }
      break;
    case 'tier-down':
      if (tierId) {
        handlers.onMoveTier(tierId, 1);
      }
      break;
    default:
      break;
  }
}

/**
 * @param {KeyboardEvent} event
 * @param {object} handlers
 */
function handleKeyDown(event, handlers) {
  if (event.key !== 'Delete' && event.key !== 'Backspace') {
    return;
  }
  const target = event.target;
  if (!(target instanceof HTMLElement) || !target.classList.contains('item')) {
    return;
  }
  const imageId = target.dataset.itemId;
  if (!imageId) {
    return;
  }
  event.preventDefault();
  handlers.onRemoveImage(imageId);
}
